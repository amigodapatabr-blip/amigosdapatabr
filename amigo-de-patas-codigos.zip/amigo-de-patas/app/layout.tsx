import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Amigo de Patas — Painel",
  description: "Gerencie doações e campanhas do Amigo de Patas.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
